Thanks for installing beta of DA UI!

Currently everything you need is available from Command Palette:
just open it and type `DA UI`.

Use `UI: Select Theme` and `UI: Select Color Scheme` commands for activation.

Install `A File Icon` package for support of the file-specific icons.

***

Found an Issue?

Please search for a similar issue first, before creating a new one:
https://github.com/ihodev/sublime-da-ui/search?q=&type=Issues

Run `DA UI: Report an Issue` command to copy all relevant details
about the environment you experienced the bug in.

Please fill out the issue template when reporting a bug or suggestion.

***

I hope you'll ❤ it.

Have a nice day! ☕
