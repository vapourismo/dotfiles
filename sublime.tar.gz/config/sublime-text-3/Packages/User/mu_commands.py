import sublime
import sublime_plugin
import subprocess
import re as regex
import threading

def runMu(args):
    print(args)
    command = list(args) # copy the list, we don't want to change the value in the caller
    command.insert(0, "C:\\workspace\\Cortex\\_make\\cygwin.msvc.release.i686\\dist\\RunMu.exe")
    output = subprocess.check_output(command, shell=True) # if there is no shell, mu will use a popup windows
    return output.decode("utf-8")

class MuCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        threading.Thread(target=lambda: self.threaded(edit)).start()

class MuGotoCommand(MuCommand):
    def threaded(self, edit):
        scope        = self.view.scope_name(self.view.sel()[-1].b)
        file         = self.view.file_name()
        ident_region = self.view.word(self.view.sel()[0])
        ident        = self.view.substr(ident_region)
        (rs, cs)     = self.view.rowcol(ident_region.a)
        (re, ce)     = self.view.rowcol(ident_region.b)
        command      = ["Strat.IDE.TypeCheck", "goto", file, ident, str(rs+1), str(cs+1), str(re+1), str(ce+1)]
        self.view.run_command("save")
        self.view.show_popup("Looking up definition...", max_width=1024)
        try:
            output = runMu(command)
            matches = regex.search("([^ ]+) (\d+) (\d+) \d+ \d+", output)
            if matches is not None:
                (file, row, col) = matches.groups()
                self.view.window().open_file(file + ":" + row + ":" + col, sublime.ENCODED_POSITION)
            else:
                raise Exception("")

        except Exception as e:
            self.view.show_popup("Could not find definition: " + str(e), max_width=1024)

class MuTypeAtPointCommand(MuCommand):
    def threaded(self, edit):
        template = """
                <body>
                    <style>
                        p {
                            margin: 0;
                            border: 0;
                        }
                        a {
                            font-family: sans-serif;
                            font-size: 1.05rem;
                        }
                        .line{
                            color: #444444;
                        }
                        #module {
                            color: #727272;
                        }
                    </style>
                    %s
                </body>
            """
        scope      = self.view.scope_name(self.view.sel()[-1].b)
        file       = self.view.file_name()
        (row, col) = self.view.rowcol(self.view.sel()[0].a)

        command = ["Strat.IDE.TypeCheck", "type", file, str(row+1), str(col+1)]
        self.view.run_command("save")
        self.view.show_popup("Mu is typing...", max_width=1024, max_height=512)
        try:
            output = runMu(command)
            if "Couldn't type" in output:
                raise Exception("")
            print(output)
            output = regex.sub(" ->\n", "<br />-> ", output)
            output = regex.sub(" :->\n", "<br />:-> ", output)

            output1 = regex.sub("([A-Z|a-z]*\.)", "", output)

            def colorModQualifier(matches):
                (module,) = matches.groups()
                return "<span id='module'>" + module + "</span>"

            output2 = regex.sub("([A-Z|a-z]*\.)", colorModQualifier, output)
            line = "-" * 20
            if output1 == output2:
                html = output1
            else:
                html = template % ("<p>%s</p><p class='line'>%s</p><p>%s</p>" % (output1, line, output2))
        except Exception as e:
            html = "No type available: " + str(e)

        self.view.show_popup(html, max_width=1024, max_height=512)
