import sublime
import sublime_plugin
import subprocess
import threading
import os.path

def invokeStylishHaskell(input, cwd = None):
    settings = sublime.load_settings('StylishHaskell.sublime-settings')
    args     = [settings.get('stylish_haskell_exe', 'stylish-haskell')]

    proc = subprocess.Popen(
        args,
        cwd = cwd,
        stdin = subprocess.PIPE,
        stdout = subprocess.PIPE,
        stderr = subprocess.PIPE
    )

    output, errors = proc.communicate(bytes(input, 'utf8'), 10)

    if proc.returncode != 0:
        print(errors.decode('utf8'))
    else:
        return output.decode('utf8')

class StylishHaskellCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        cwd = os.path.dirname(self.view.file_name())

        totalRegion = sublime.Region(0, self.view.size())
        contents    = self.view.substr(totalRegion)
        newContents = invokeStylishHaskell(contents, cwd)

        if newContents != None:
            self.view.replace(edit, totalRegion, newContents)

class StylishHaskellOnSave(sublime_plugin.EventListener):
    def on_pre_save(self, view):
        settings      = sublime.load_settings('StylishHaskell.sublime-settings')
        localSettings = view.settings()

        runOnSave = localSettings.get(
            'stylish_haskell_on_save',
            settings.get('stylish_haskell_on_save', False)
        )

        if not runOnSave:
            return

        extension = view.file_name()[-2:].lower()
        if extension == 'mu' or extension == 'hs':
            view.window().run_command('stylish_haskell')
