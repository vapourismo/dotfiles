import sublime
import sublime_plugin
import webbrowser
import urllib.request
import urllib.parse
import re
import html.parser

class MuHoogleCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        def on_done(input):
            params = urllib.parse.urlencode({'hoogle': input + ' +strat +mu +libraries +base', 'start': 200})
            url = "http://appvdev4124.uk.standardchartered.com:1500/?%s" % params
            print(url)
            response = urllib.request.urlopen(url)
            html = response.read().decode("iso-8859-1")
            regex = re.compile("<a class='dull' href='(.*?)'>(.*?)</a><a class='a'.*?>(.*?)</a><a class='dull'.*?>(.*?)</a>.*?<a class='p2'.*?>(.*?)</a>", re.DOTALL)
            hits = re.findall(regex, html)
            urls = [hit[0] for hit in hits]
            names = [format(hit[1], hit[2], hit[3], hit[4])
                        for hit in hits]
            print(len(names))
            sublime.active_window().show_quick_panel(names, lambda ix: on_selected(ix, urls))

        def format(definition, name, type, module):
            definition = definition.replace("<i>", "").replace("</i>", "")
            name = name.replace("<b>", "").replace("</b>", "")
            type = (type.replace("<span class='c0'>", '')
                        .replace("<span class='c1'>", '')
                        .replace("<span class='c2'>", '')
                        .replace("<span class='c3'>", '')
                        .replace("<span class='c4'>", '')
                        .replace("<span class='c5'>", '')
                        .replace('</span>', ''))

            p = html.parser.HTMLParser()
            if (re.match("\s*::", type)):
                l1 = definition + name
                l2 = type
            elif (re.match("(data)|(type)|(class)", definition)):
                l1 = definition + name + type
                l2 = module
            else:
                l1 = definition + name + type
                l2 = ""
            return ([p.unescape(l1), p.unescape(l2)])

        def on_selected(index, urls):
            if index != -1:
                webbrowser.open(urls[index])

        ident = self.view.substr(self.view.sel()[0])
        self.view.window().show_input_panel("Hoogle", ident, on_done, None, None)
